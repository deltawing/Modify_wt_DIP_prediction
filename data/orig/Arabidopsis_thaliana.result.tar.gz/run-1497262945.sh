#!/bin/sh
#$ -S /bin/bash
#$ -v PATH=/home/data/webcomp/RAMMCAP-ann/bin:/sbin:/usr/sbin:/bin:/usr/bin
#$ -v BLASTMAT=/home/data/webcomp/RAMMCAP-ann/blast/bin/data
#$ -v LD_LIBRARY_PATH=/home/data/webcomp/RAMMCAP-ann/gnuplot-install/lib
#$ -v PERL5LIB=/home/hying/programs/Perl_Lib
#$ -q cdhit_webserver.q
##$ -pe orte 4


#$ -e /home/oasis/webcomp/web-session/1497262945/1497262945.err
#$ -o /home/oasis/webcomp/web-session/1497262945/1497262945.out
cd /home/oasis/webcomp/web-session/1497262945
faa_stat.pl 1497262945.fas.0

/home/oasis/gordon-data/NGS-ann-project/apps/cd-hit-v4.6.7-2017-0501/cd-hit -i 1497262945.fas.0 -d 0 -o 1497262945.fas.1 -c 0.4 -n 2  -G 1 -g 1 -b 20 -s 0.0 -aL 0.0 -aS 0.0 -T 4 -M 32000
faa_stat.pl 1497262945.fas.1
/home/oasis/gordon-data/NGS-ann-project/apps/cd-hit-v4.6.7-2017-0501/clstr_sort_by.pl no < 1497262945.fas.1.clstr > 1497262945.fas.1.clstr.sorted
/home/oasis/gordon-data/NGS-ann-project/apps/cd-hit-v4.6.7-2017-0501/clstr_list.pl 1497262945.fas.1.clstr 1497262945.clstr.dump
gnuplot1.pl < 1497262945.fas.1.clstr > 1497262945.fas.1.clstr.1; gnuplot2.pl 1497262945.fas.1.clstr.1 1497262945.fas.1.clstr.1.png
/home/oasis/gordon-data/NGS-ann-project/apps/cd-hit-v4.6.7-2017-0501/clstr_list_sort.pl 1497262945.clstr.dump 1497262945.clstr_no.dump
/home/oasis/gordon-data/NGS-ann-project/apps/cd-hit-v4.6.7-2017-0501/clstr_list_sort.pl 1497262945.clstr.dump 1497262945.clstr_len.dump len
/home/oasis/gordon-data/NGS-ann-project/apps/cd-hit-v4.6.7-2017-0501/clstr_list_sort.pl 1497262945.clstr.dump 1497262945.clstr_des.dump des
tar -zcf 1497262945.result.tar.gz * --exclude=*.dump --exclude=*.env
echo hello > 1497262945.ok
